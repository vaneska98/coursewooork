from vehicle import *
from car import *
from motorbike import *

def main():
  car = Car("golf", 20, 0.1, 4)
  car.print_car_info()

  car.travel_distance(300)
  car.travel_distance(100)
  #След изминатото разстояние
  car.print_car_info()
  
  motorbike = Motorbike("yamaha", 20, 0.2) 
  motorbike.print_motorbike_info()
  motorbike.travel_distance(100)

  #След изминатото разстояние
  motorbike.print_motorbike_info()
  
  #Сравняваме изминатото разстояние на колата и мотора
  car.compare_distance_travelled(motorbike)



if __name__ == "__main__":
  main()