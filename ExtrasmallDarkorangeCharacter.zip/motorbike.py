from vehicle import *

class Motorbike(Vehicle):
  def __init__(self, model,fuel_amount,fuel_cost_per_km):
    super().__init__(model,fuel_amount,fuel_cost_per_km)
    self.number_of_wheels = 2
    self.number_of_doors = 0

  def print_motorbike_info(self):
    self.print_info()
    print("Number of wheels: ", self.number_of_wheels)
    print("Number of doors: ", self.number_of_doors)