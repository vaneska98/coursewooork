from vehicle import *

class Car(Vehicle):
  def __init__(self, model,fuel_amount,fuel_cost_per_km, number_of_doors):
    super().__init__(model,fuel_amount,fuel_cost_per_km)
    self.number_of_wheels = 4
    self.number_of_doors = number_of_doors

  def print_car_info(self):
    self.print_info()
    print("Number of wheels: ",self.number_of_wheels)
    print("Number of doors: ",self.number_of_doors)